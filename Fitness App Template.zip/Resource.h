//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FitnessApp.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FITNESSAPP_DIALOG           102
#define IDR_MAINFRAME                   128
#define txtUserHeightInch               1000
#define txtUserWeeklyGoal               1001
#define txtUserWeight                   1002
#define btnSave                         1004
#define txtUserAge                      1005
#define txtUserGender                   1006
#define txtUserHeightFeet               1007
#define txtToDo1                        1009
#define txtToDo2                        1010
#define txtToDo3                        1011
#define txtToDo4                        1012
#define txtToDo5                        1013
#define IDC_CHECK1                      1016
#define IDC_CHECK2                      1017
#define IDC_CHECK3                      1018
#define IDC_CHECK4                      1019
#define IDC_CHECK5                      1020
#define txtMondayCals                   1022
#define txtWednesdayCals                1023
#define txtTuesdayCals                  1024
#define txtThursdayCals                 1025
#define txtFridayCals                   1026
#define txtSaturdayCals                 1027
#define txtSundayCals                   1028
#define txtTotalWeekCals                1029
#define txtWeeklyGoal                   1030
#define txtGoalPercent                  1031
#define IDC_SPIN1                       1032
#define txtHoursSlept                   1033
#define txtSummaryIntake                1034
#define btnWorkOutUpdate                1035
#define txtSummaryHoursSlept            1042
#define txtSummaryCupsWater             1043

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
